import React, { useState } from "react";
import axios from "axios";

function App() {
  const [script, setScript] = useState("");
  const [videoURL, setVideoURL] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const res = await axios.post("https://your-backend-url.onrender.com/generate", { script });
      setVideoURL(res.data.video_url);
    } catch (err) {
      alert("Failed to generate video.");
    }
    setLoading(false);
  };

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: "auto" }}>
      <h1>Swagat hai hamare Script2Shorts Website mein</h1>
      <textarea rows="10" value={script} onChange={(e) => setScript(e.target.value)} placeholder="Apna script yahan likho..." style={{ width: "100%" }} />
      <button onClick={handleSubmit} disabled={loading} style={{ marginTop: 10 }}>
        {loading ? "Generating..." : "Generate Video"}
      </button>
      {videoURL && (
        <div style={{ marginTop: 20 }}>
          <video width="100%" controls>
            <source src={videoURL} type="video/mp4" />
          </video>
          <a href={videoURL} download>
            <button style={{ marginTop: 10 }}>Download Video</button>
          </a>
        </div>
      )}
    </div>
  );
}

export default App;